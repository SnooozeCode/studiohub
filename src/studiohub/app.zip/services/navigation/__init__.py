"""Navigation services module."""
from __future__ import annotations

from studiohub.services.navigation.navigation_service import NavigationService

__all__ = ["NavigationService"]
