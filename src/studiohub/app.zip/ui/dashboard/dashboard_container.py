from PySide6.QtWidgets import QFrame, QLabel, QVBoxLayout, QWidget, QSizePolicy
from PySide6.QtCore import Qt


class DashboardSurface(QFrame):
    """
    The canonical dashboard panel surface.
    This is where theme tokens apply.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("DashboardSurface")
        self.setFrameShape(QFrame.NoFrame)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        self._layout = layout

    def add_content(self, widget: QWidget):
        self._layout.addWidget(widget)

class DashboardContainer(QFrame):
    """
    Clean dashboard panel container.
    Title stays at the top, content fills the rest.
    """

    def __init__(self, title: str, content: QWidget, parent=None):
        super().__init__(parent)

        self.setObjectName("DashboardSurface")
        self.setFrameShape(QFrame.NoFrame)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        # Title - explicitly set to stay at top
        title_label = QLabel(title)
        title_label.setObjectName("DashboardCardTitle")
        title_label.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        title_label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)

        # Content - should expand
        content.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        layout.addWidget(title_label)
        layout.addWidget(content)