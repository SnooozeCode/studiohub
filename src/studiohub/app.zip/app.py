"""
Application bootstrap entrypoint.

This file will own QApplication setup in later phases.
Currently unused.
"""
