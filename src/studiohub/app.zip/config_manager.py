"""
LEGACY SHIM — temporary compatibility layer.

Do not add logic here.
"""

from studiohub.config.manager import ConfigManager
